"""Stage 0: an explicit plan in, a capture-ready trace out.

The mechanical stages only solidify commands whose inputs and outputs are on the
command line, so a session full of probes, inline code and script-internal writes
cannot be captured as it stands. Distilling is the agent's job: it reads the
session, decides which steps are the business chain, materialises the scripts on
disk and declares every path on the command line. This module holds the result to
the same contract the capture stages enforce, and says what to fix instead of
half-building a graph.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Sequence

from builder import CompileError

from ..service import GenomeService
from .align import DEFAULT_THRESHOLD, Alignment, align_traces, render_alignment
from .emit import (DEFAULT_VERSION, EmitError, Package, build_package, read_many,
                   render_emit, source_for)
from .pipeline import asset_resolver
from .policy import POLICY_SCRIPTS_FIRST, normalize_policy
from .slice import OUTPUT_CONTRACT_HINT, Slice, SliceError, render_slice, reverse_slice
from .trace import (INLINE_MARK, KIND_HUMAN, KIND_LLM, KIND_SHELL, KIND_TOOL, KIND_WRITE,
                    ROLE_SCRIPT, TRACE_VERSION, Command, Trace, arg_paths, canonical_path,
                    capture_trace, parse_command, placeholder_key, probe_command, role)

MAX_STEPS = 200
KIND_RUN = "run"
AUXILIARY_REASON = ("产出没有被链路里的后续步骤消费，不在最终产物的依赖闭包里；"
                    "要固化它，请单独用 final_artifact 指向它的产出再沉淀一条经验")
_TOKEN_BOUNDARY = r"(?<![\w./-])"
_SCRIPT_TOKEN = re.compile(r"[\w./-]+\.(?:py|sh|js|ts|r|rb|sql)\b")
_TOOL_NAME = re.compile(r"^[a-z][a-z0-9_.-]*$")


class DistillError(ValueError):
    pass


@dataclass(frozen=True)
class DistilledStep:
    order: int
    run: str
    derived_from: str | None
    reads: tuple[str, ...]
    writes: tuple[str, ...]
    kind: str = KIND_RUN
    verify: str | None = None
    tool_name: str | None = None
    arguments: Mapping[str, Any] | None = None

    def payload(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "step": self.order,
            "kind": self.kind,
            "from": self.derived_from,
            "reads": list(self.reads),
            "writes": list(self.writes),
        }
        if self.kind == KIND_TOOL:
            data["tool"] = self.tool_name
            data["args"] = dict(self.arguments or {})
        else:
            data["run"] = self.run
        if self.verify:
            data["verify"] = self.verify
        return data


def _run_text(raw: Mapping[str, Any], order: int) -> str:
    value = raw.get("run")
    if not isinstance(value, str) or not value.strip():
        raise DistillError(f"第 {order} 步缺少 run：要执行的完整 shell 命令")
    return value.strip()


def _derived_from(raw: Mapping[str, Any], order: int) -> str | None:
    derived = raw.get("from")
    if derived is None:
        return None
    if not isinstance(derived, str) or not derived.strip():
        raise DistillError(
            f"第 {order} 步的 from 必须是非空字符串（来源轨迹，如 `<trace_id>:<seq>`）")
    return derived.strip()


def _llm_text(raw: Mapping[str, Any], order: int) -> str:
    value = raw.get("llm")
    if not isinstance(value, str) or not value.strip():
        raise DistillError(f"第 {order} 步的 llm 必须是非空的提示词模板字符串")
    return value.strip()


def _llm_io(raw: Mapping[str, Any], order: int) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """The declared inputs and the single artifact of a distilled llm step.

    A shell step derives these from its command line; a prompt has no such structure,
    so the agent declares them and the same chain/clone checks apply.
    """
    output = raw.get("output")
    if not isinstance(output, str) or not output.strip():
        raise DistillError(
            f"第 {order} 步是 llm 节点，必须用 output 声明它产出的 artifact 路径，"
            "并在提示词里原样引用同一个路径")
    inputs = raw.get("input")
    if inputs is None:
        inputs = []
    elif isinstance(inputs, str):
        inputs = [inputs]
    if (not isinstance(inputs, list)
            or any(not isinstance(item, str) or not item.strip() for item in inputs)):
        raise DistillError(f"第 {order} 步的 input 必须是路径字符串列表（可省略）")
    return tuple(item.strip() for item in inputs), (output.strip(),)


def _llm_verify(raw: Mapping[str, Any], order: int) -> str | None:
    value = raw.get("verify")
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise DistillError(f"第 {order} 步的 verify 必须是非空的验收命令字符串")
    return value.strip()


def _check_llm_prompt(step: DistilledStep) -> None:
    """Every declared path has to appear in the prompt so emit can slot it in."""
    missing = [token for token in (*step.reads, *step.writes) if token not in step.run]
    if missing:
        raise DistillError(
            f"第 {step.order} 步的 llm 提示词必须原样出现它声明的输入/产出路径，缺少："
            + "、".join(f"`{token}`" for token in missing))


def _tool_name(raw: Mapping[str, Any], order: int) -> str:
    value = raw.get("tool")
    if not isinstance(value, str) or not value.strip():
        raise DistillError(f"第 {order} 步的 tool 必须是非空的宿主工具名")
    name = value.strip()
    if not _TOOL_NAME.match(name):
        raise DistillError(
            f"第 {order} 步的 tool 名 `{name}` 不合法：只允许小写字母开头，"
            "其余是小写字母、数字、`.`、`_`、`-`")
    return name


def _tool_args(raw: Mapping[str, Any], order: int) -> dict[str, Any]:
    args = raw.get("args")
    if args is None:
        return {}
    if not isinstance(args, Mapping):
        raise DistillError(f"第 {order} 步的 args 必须是对象：工具收到的参数键值")
    return {str(key): value for key, value in args.items()}


def _strings(value: Any) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, Mapping):
        return [text for item in value.values() for text in _strings(item)]
    if isinstance(value, (list, tuple)):
        return [text for item in value for text in _strings(item)]
    return []


def _tool_io(raw: Mapping[str, Any], order: int) -> tuple[tuple[str, ...], str, dict[str, Any]]:
    """A tool step's declared inputs, its artifact, and the call's args.

    The args are values rather than a command line, so the inputs are read off them; an
    explicit `input` declaration is checked against the args and kept first, so an
    id-shaped parameter that does not spell like a path can still become a graph input.
    """
    output = raw.get("output")
    if not isinstance(output, str) or not output.strip():
        raise DistillError(
            f"第 {order} 步是 tool 节点，必须用 output 声明工具返回的 JSON 写进哪个 artifact 路径")
    declared = raw.get("input")
    if declared is None:
        declared = []
    elif isinstance(declared, str):
        declared = [declared]
    if (not isinstance(declared, list)
            or any(not isinstance(item, str) or not item.strip() for item in declared)):
        raise DistillError(f"第 {order} 步的 input 必须是路径字符串列表（可省略）")
    args = _tool_args(raw, order)
    values = _strings(args)
    reads = [item.strip() for item in declared]
    missing = [token for token in reads if not any(token in value for value in values)]
    if missing:
        raise DistillError(
            f"第 {order} 步声明了 input，但 args 里找不到它们："
            + "、".join(f"`{token}`" for token in missing)
            + "。工具只会收到 args 里的值，请把输入写进 args")
    for path in arg_paths(args):
        if path not in reads:
            reads.append(path)
    return tuple(reads), output.strip(), args


def _check_command(run: str, command: Command, order: int) -> None:
    if INLINE_MARK in command.shape:
        raise DistillError(
            f"第 {order} 步是内联代码，无法机械固化：`{run}`。"
            "请把代码落盘成脚本文件，再用命令行调用它；heredoc 与 -c 都不算落盘")
    if probe_command(command):
        raise DistillError(
            f"第 {order} 步是只读探测命令，不会进图：`{run}`。请删掉它，只留业务链路")
    if not command.read_paths and not command.write_paths:
        raise DistillError(
            f"第 {order} 步既没有输入也没有产出（命令里没有可识别的路径）：`{run}`。"
            "请把输入和产出写成命令行上的路径")


def plan_steps(steps: Sequence[Any]) -> tuple[DistilledStep, ...]:
    """Validate the agent's chain against the capture contract, step by step."""
    if isinstance(steps, (str, bytes)) or not isinstance(steps, Sequence) or not steps:
        raise DistillError(
            "distill 需要 steps：[{run, from?}]、[{llm, output, input?, from?}] 或 "
            "[{tool, args, output, input?, from?}]，按链路顺序排列")
    if len(steps) > MAX_STEPS:
        raise DistillError(f"步骤过多（{len(steps)}），最多 {MAX_STEPS} 步")
    planned: list[DistilledStep] = []
    for order, raw in enumerate(steps, start=1):
        if not isinstance(raw, Mapping):
            raise DistillError(f"第 {order} 步必须是对象：{{run, from?}}、"
                               f"{{llm, output, input?, from?}} 或 {{tool, args, output, from?}}")
        forms = [key for key in ("run", "llm", "tool") if key in raw]
        if len(forms) > 1:
            raise DistillError(
                f"第 {order} 步不能同时声明 {'、'.join(forms)}，只能取其一")
        derived = _derived_from(raw, order)
        if "tool" in raw:
            name = _tool_name(raw, order)
            reads, output, args = _tool_io(raw, order)
            planned.append(DistilledStep(order, f"<tool:{name}>", derived, reads, (output,),
                                         kind=KIND_TOOL, tool_name=name, arguments=args))
            continue
        if "llm" in raw:
            step = DistilledStep(order, _llm_text(raw, order), derived,
                                 *_llm_io(raw, order), kind=KIND_LLM,
                                 verify=_llm_verify(raw, order))
            _check_llm_prompt(step)
            planned.append(step)
            continue
        run = _run_text(raw, order)
        command = parse_command(run)
        _check_command(run, command, order)
        planned.append(DistilledStep(order, run, derived,
                                     command.read_paths, command.write_paths))
    return tuple(planned)


def _check_chain(traces: Sequence[Trace], planned: Sequence[DistilledStep],
                 params: Mapping[str, Any] | None) -> tuple[tuple[str | None, str], ...]:
    """A plan may not silently drop a session step its inputs depend on.

    Only the session knows what really produced a path. When the plan reads a path
    that an earlier successful session step wrote, that producer has to be either
    part of the plan, or an explicitly declared chain boundary (a placeholder bound
    to that path). Boundaries are reported, never silently accepted. Each boundary
    keeps its parameter name so a later stage can tell whether it still applies.
    """
    produced: dict[str, tuple[str, int, str, str]] = {}
    for trace in traces:
        for step in trace.steps:
            if (step.kind not in (KIND_SHELL, KIND_WRITE, KIND_TOOL)
                    or step.rejected or not step.success):
                continue
            for path in step.write_paths:
                produced.setdefault(path, (trace.trace_id, step.seq, step.kind,
                                           step.command, step))
    given = bindings(params)
    # A step that writes `{out}` produces the path that placeholder binds to, so a
    # later step reading either spelling is fed by this plan, not by the session.
    plan_paths = {canonical_path(path, given) for step in planned for path in step.writes}
    missing: list[str] = []
    boundaries: list[tuple[str | None, str]] = []
    declared: set[str] = set()
    for order, step in enumerate(planned, start=1):
        for path in step.reads:
            key = placeholder_key(path)
            concrete = given.get(key, "") if key else path
            if not concrete or concrete in plan_paths:
                continue
            producer = produced.get(concrete)
            if producer is None:
                continue
            trace_id, seq, kind, command, producer_step = producer
            if key:
                if concrete not in declared:
                    declared.add(concrete)
                    if _command_expressible(producer_step):
                        raise DistillError(
                            f"第 {order} 步把 `{concrete}` 声明为输入边界（参数 `{key}`），"
                            f"但它在会话里由固定命令产出：`{trace_id}:{seq}` `{command}`。"
                            "固定调用形式的步骤必须进 steps，不能降级成输入边界；"
                            "只有编辑工具、人工或纯 agent 产生的产物才允许作为输入边界。"
                        )
                    boundaries.append((key,
                        f"链路以 `{concrete}` 为输入边界（参数 `{key}`），它在会话里由 "
                        f"`{trace_id}:{seq}` 产出，该步骤未固化；要完整链路请把它补进 steps。"))
                continue
            detail = (f"第 {order} 步读取 `{concrete}`，但它在会话里由 `{trace_id}:{seq}` 产出，"
                      f"而这一步不在沉淀链路里。")
            if kind == KIND_WRITE:
                detail += ("该产出由编辑工具写入，内容无法机械固化；请把产出改成脚本执行，")
            else:
                detail += f"产出命令：`{command}`；请把这一步补进 steps，"
            detail += ("或改用 `{参数名}` 占位符 + params 给出它的真实值："
                       "写进工作区的脚本会被随包搬运并固化成 graph 步骤，"
                       "其它产物则作为链路输入边界写进报告。")
            missing.append(detail)
    if missing:
        raise DistillError("链路不完整，缺少上游步骤：\n" + "\n".join(f"- {item}" for item in missing))
    return tuple(boundaries)


def _command_expressible(step: Any) -> bool:
    """Whether the graph could replay this session step as a fixed call.

    A session tool call the exporter could not map to a known tool is exactly as
    fixed as a shell command; it only lacks the artifact declaration a distilled
    tool step carries, which is why it stays out of the graph as captured.
    """
    if step.kind == KIND_TOOL:
        return True
    return (step.kind == KIND_SHELL and not step.inline_code
            and bool(step.command_shape))


def _reject_gaps_naming_commands(gaps: Sequence[Mapping[str, Any]] | None,
                                 traces: Sequence[Trace]) -> None:
    """A gap may not name a script the session already ran as a fixed command."""
    if not gaps:
        return
    names: set[str] = set()
    for trace in traces:
        for step in trace.steps:
            if step.kind == KIND_TOOL and step.tool_name:
                names.add(step.tool_name)
                continue
            if not _command_expressible(step):
                continue
            names.update(PurePosixPath(match.group(0)).name
                         for match in _SCRIPT_TOKEN.finditer(step.command))
    if not names:
        return
    for index, gap in enumerate(gaps):
        text = " ".join(str(gap.get(key) or "") for key in ("reason", "reference"))
        hit = next((name for name in sorted(names) if name in text), None)
        if hit is not None:
            raise DistillError(
                f"gaps[{index}] 把 `{hit}` 声明成不可固化，但它在会话里是由固定命令执行的。"
                "有 LLM 参与不等于不可固化：请把对应命令补进 steps（固定工具调用用 tool 步骤）；"
                "只有纯 agent 裁量、编辑工具产物、内联代码或人工门禁才进 gaps。"
            )


def _candidate_steps(traces: Sequence[Trace], limit: int = 20) -> str:
    """The session steps an llm node could point at, for the rejection message."""
    lines: list[str] = []
    for trace in traces:
        for step in trace.steps:
            command = " ".join(step.command.split())[:120] or "-"
            lines.append(f"- `{trace.trace_id}:{step.seq}` [{step.kind}] {command}")
            if len(lines) == limit:
                return "\n".join([*lines, "- ……"])
    return "\n".join(lines) or "- （会话里没有可引用的步骤）"


def _check_llm_promotions(planned: Sequence[DistilledStep], traces: Sequence[Trace],
                          policy: str) -> None:
    """An llm node may not stand in for a session step the graph could run or must gate.

    A fixed command belongs in `run` (LLM calls inside a script do not make it free-form),
    and a human gate or an editor-written artifact is not an agent task at all — it has to
    be a gap. Only a genuine agent-discretion step becomes `do: {llm}`.

    `scripts-first` (default) enforces that mechanically: every llm node has to name the
    session step it came from, and that step may not be a fixed command. `adaptive-first`
    trusts the agent's classification instead and only keeps the human/editor checks.
    """
    if not traces:
        return
    index = {f"{trace.trace_id}:{step.seq}": step for trace in traces for step in trace.steps}
    strict = policy == POLICY_SCRIPTS_FIRST
    for step in planned:
        if step.kind != KIND_LLM:
            continue
        source = index.get(step.derived_from) if step.derived_from else None
        if source is None:
            if not strict:
                continue
            if step.derived_from:
                raise DistillError(
                    f"第 {step.order} 步的 from `{step.derived_from}` 不在 source_traces 里。"
                    "请填这一步真正来源的 `<trace_id>:<seq>`，会话里可选的步骤：\n"
                    f"{_candidate_steps(traces)}")
            raise DistillError(
                f"第 {step.order} 步声明成 llm 节点但没有 from：请补上这一步来源的 "
                "`<trace_id>:<seq>`，插件据此核对它不是固定命令。会话里可选的步骤：\n"
                f"{_candidate_steps(traces)}")
        if source.kind == KIND_TOOL:
            raise DistillError(
                f"第 {step.order} 步声明成 llm 节点，但它在会话里是固定工具调用："
                f"`{step.derived_from}` `{source.tool_name}`。固定调用有确定的调用形式，"
                "请用 tool 步骤（tool/args/output）提交，交给 graph 直接执行。")
        if strict and _command_expressible(source):
            raise DistillError(
                f"第 {step.order} 步声明成 llm 节点，但它在会话里是固定命令："
                f"`{step.derived_from}` `{source.command}`。有 LLM 参与、产出内容会变都不等于"
                "自由裁量：只要调用形式固定，就用 run 提交，交给 graph 重跑。")
        if source.kind in (KIND_HUMAN, KIND_WRITE):
            raise DistillError(
                f"第 {step.order} 步声明成 llm 节点，但它在会话里是"
                f"{'人工门禁' if source.kind == KIND_HUMAN else '编辑工具写入'}："
                f"`{step.derived_from}`。这类步骤没有固定的 agent 调用形式，"
                "请写进 gaps（配 references 说明怎么做），不要变成 llm 节点。")


def _replace_token(run: str, token: str, value: str) -> tuple[str, int]:
    """Replace one whole shell token, keeping the original quoting style intact."""
    quoted = re.escape(token)
    pattern = re.compile(
        _TOKEN_BOUNDARY + r"(?:'" + quoted + r"'|\"" + quoted + r"\"|" + quoted
        + r")(?![\w./-])"
    )
    return pattern.subn(value, run)


def _materialize_scripts(
        planned: Sequence[DistilledStep], params: Mapping[str, Any] | None,
        workspace: Any) -> tuple[tuple[DistilledStep, ...], dict[str, str],
                                 tuple[tuple[str, str], ...], tuple[str, ...]]:
    """Freeze a `{param}` that points at a script instead of leaving it an input boundary.

    The session produced the script with an editor tool, so the capture contract cannot
    take it as a graph step; declaring it a parameter would keep it outside the package
    and every reuse would have to rewrite it. Rewriting the command to the concrete path
    lets the emit stage copy the script like any other script read on the command line.
    A script the workspace cannot read stays an input boundary, and the report says so.
    """
    given = {str(key): str(value) for key, value in (params or {}).items()}
    if not given:
        return tuple(planned), given, (), ()
    produced = {path for step in planned for path in step.writes}
    source = source_for(workspace)
    candidates: list[tuple[str, str]] = []
    seen: set[str] = set()
    for step in planned:
        if step.kind != KIND_RUN:
            continue
        for path in step.reads:
            key = placeholder_key(path)
            if key is None or key not in given or key in seen:
                continue
            value = given[key]
            if role(value, writing=False) != ROLE_SCRIPT or value in produced:
                continue
            seen.add(key)
            candidates.append((key, value))
    contents = read_many(source, [value for _, value in candidates])
    frozen: dict[str, str] = {}
    unreadable: set[str] = set()
    notes: list[str] = []
    for key, value in candidates:
        if contents.get(value) is None:
            unreadable.add(key)
            notes.append(
                f"参数 `{key}` 指向脚本 `{value}`，但工作区里读不到它，"
                "仍按输入边界处理（包内没有这份脚本）。")
            continue
        frozen[key] = value
    if not frozen:
        return tuple(planned), given, (), tuple(notes)
    rewritten: list[DistilledStep] = []
    replaced: set[str] = set()
    for step in planned:
        if step.kind != KIND_RUN:
            rewritten.append(step)
            continue
        run = step.run
        for key, value in frozen.items():
            if not any(placeholder_key(item) == key for item in step.reads):
                continue
            run, count = _replace_token(run, f"{{{key}}}", value)
            if count:
                replaced.add(key)
        command = parse_command(run)
        rewritten.append(DistilledStep(step.order, run, step.derived_from,
                                       command.read_paths, command.write_paths,
                                       kind=step.kind, verify=step.verify))
    materialized = tuple(sorted((key, value) for key, value in frozen.items()
                                if key in replaced))
    return (tuple(rewritten), {key: value for key, value in given.items()
                               if key not in replaced},
            materialized, tuple(notes))


def _bound_values(package: Package, planned: Sequence[DistilledStep],
                  params: Mapping[str, Any] | None) -> tuple[tuple[str, str], ...]:
    """Replay A's concrete inputs: what the placeholders and root paths bind to.

    `params` may also carry the placeholders the chain writes or passes between its
    own steps — agents name every `{token}` their commands use. Those bindings are
    not root inputs, so they stay out of the replay; a key no step uses is still a
    mistake and gets reported.
    """
    expected = {key for key, _ in package.params}
    if params is None:
        unbound = sorted(key for key, value in package.params if placeholder_key(value))
        if unbound:
            hint = "、".join(f"`{key}`" for key in unbound)
            example = ", ".join(f"{key}: <路径>" for key in unbound)
            raise DistillError(
                f"命令里用了占位符输入：{hint}。distill 需要 params 给出回放 A 的真实值，"
                f"例如 params: {{{example}}}")
        return package.params
    given = tuple((str(key), str(value)) for key, value in params.items())
    keys = {key for key, _ in given}
    used: set[str] = set()
    for step in planned:
        for path in (*step.reads, *step.writes):
            key = placeholder_key(path)
            if key is not None:
                used.add(key)
    if keys - expected - used or expected - keys:
        raise DistillError(
            f"params 必须覆盖链路的根输入：需要 {sorted(expected)}，"
            f"收到 {sorted(keys)}。根输入来自命令里的路径与 {{占位符}}")
    return tuple((key, value) for key, value in given if key in expected)


def _step_material(step: DistilledStep) -> list[Any]:
    """What makes one step distinct, for the trace id a retry of the plan reuses."""
    if step.kind == KIND_TOOL:
        return [step.kind, step.tool_name, dict(step.arguments or {}), list(step.writes)]
    return [step.kind, step.run]


def _trace_id(label: str, steps: Sequence[DistilledStep],
              source_traces: Sequence[str]) -> str:
    """The same plan always distils to the same trace, so a retry is a reuse."""
    material = json.dumps([label, [_step_material(step) for step in steps],
                           list(source_traces)],
                          ensure_ascii=False, sort_keys=True)
    return f"distilled-{hashlib.sha256(material.encode('utf-8')).hexdigest()[:12]}"


def _trace_entry(step: DistilledStep) -> dict[str, Any]:
    """The capture-trace entry for one distilled step, carrying where it came from."""
    entry_id = step.derived_from or f"distilled-{step.order}"
    if step.kind == KIND_TOOL:
        return {
            "kind": "tool_call",
            "entry_id": entry_id,
            "timestamp": None,
            "tool": step.tool_name,
            "call_id": f"distilled-{step.order}",
            "args": dict(step.arguments or {}),
            "output": step.writes[0],
            "result": {"is_error": False, "text": "distilled"},
        }
    if step.kind == KIND_LLM:
        return {
            "kind": "llm",
            "entry_id": entry_id,
            "timestamp": None,
            "tool": "llm",
            "call_id": f"distilled-{step.order}",
            "args": {"prompt": step.run, "reads": list(step.reads),
                     "writes": list(step.writes), "verify": step.verify or ""},
            "result": {"is_error": False, "text": "distilled"},
        }
    return {
        "kind": "tool",
        "entry_id": entry_id,
        "timestamp": None,
        "tool": "terminal",
        "call_id": f"distilled-{step.order}",
        "args": {"command": step.run},
        "result": {"is_error": False, "text": "distilled"},
    }


def trace_document(label: str, steps: Sequence[DistilledStep], *,
                   source_traces: Sequence[str] = ()) -> dict[str, Any]:
    """A trace the capture stages accept, carrying where each step came from."""
    return {
        "trace_version": TRACE_VERSION,
        "trace_id": _trace_id(label, steps, source_traces),
        "session_id": None,
        "session_name": label,
        "step_count": len(steps),
        "dropped_steps": 0,
        "source_traces": list(source_traces),
        "steps": [_trace_entry(step) for step in steps],
    }


def bindings(params: Mapping[str, Any] | None) -> dict[str, str]:
    """The concrete path each `{param}` placeholder stands for in this plan."""
    return {str(key): str(value) for key, value in (params or {}).items()}


def _spell_out(path: str, bindings: Mapping[str, str]) -> str:
    concrete = canonical_path(path, bindings)
    return f"`{path}`" if concrete == path else f"`{path}`（= `{concrete}`）"


def _check_final_artifact(final_artifact: str, steps: Sequence[DistilledStep],
                          params: Mapping[str, Any] | None = None) -> str:
    """The plan write this artifact names, whichever spelling the agent used.

    A step may write `{sft_messages}` while the artifact is declared by the concrete
    path that placeholder binds to, or the other way round; both name one file, so
    the plan keeps the token it wrote and the slice follows that token.
    """
    given = bindings(params)
    wanted = canonical_path(final_artifact, given)
    for step in steps:
        for path in step.writes:
            if canonical_path(path, given) == wanted:
                return path
    produced = [_spell_out(path, given) for step in steps for path in step.writes]
    detail = ("计划里的产出：" + "、".join(produced[:8])
              if produced else "计划里没有任何产出")
    raise DistillError(
        f"final_artifact `{final_artifact}` 没有被任何步骤声明为产出；{detail}。"
        f"{OUTPUT_CONTRACT_HINT}")


@dataclass(frozen=True)
class DistillPlan:
    trace: Trace
    document: dict[str, Any]
    steps: tuple[DistilledStep, ...]
    directory: Path
    package: Package
    auxiliary: tuple[int, ...]
    chain_traces: tuple[str, ...] = ()
    boundaries: tuple[str, ...] = ()
    bound: tuple[tuple[str, str], ...] = ()
    materialized: tuple[tuple[str, str], ...] = ()
    materialize_notes: tuple[str, ...] = ()
    policy: str = POLICY_SCRIPTS_FIRST

    @property
    def report_path(self) -> Path:
        return self.directory / "report.md"

    def payload(self) -> dict[str, Any]:
        return {
            "trace_id": self.trace.trace_id,
            "trace": self.document,
            "report": str(self.report_path),
            "package": str(self.package.directory),
            "steps": [step.payload() for step in self.steps],
            "params": [{"key": key, "source": path, "value": dict(self.bound).get(key)}
                       for key, path in self.package.params],
            "chain": {"checked": bool(self.chain_traces),
                      "traces": list(self.chain_traces),
                      "boundaries": list(self.boundaries)},
            "materialized": [{"key": key, "path": path}
                             for key, path in self.materialized],
            "materialize_notes": list(self.materialize_notes),
            "policy": self.policy,
            "scripts": [{"source": source, "package": target}
                        for source, target in self.package.scripts],
            "nodes": [{"step": node.order + 1, "id": node.id, "kind": node.kind,
                       "command": node.command}
                      for node in self.package.nodes],
            "not_solidifiable": [{"step": order + 1, "reason": reason}
                                 for order, reason in self.package.not_solidifiable],
            "auxiliary": [{"step": order + 1, "reason": AUXILIARY_REASON}
                          for order in self.auxiliary],
            "final_artifact": self.package.final_artifact,
            "references": list(self.package.references),
            "gaps": list(self.package.gaps),
            **self.package.applicability,
        }

    def summary(self) -> dict[str, Any]:
        """The payload without the trace document: a caller already has the trace."""
        return {key: value for key, value in self.payload().items() if key != "trace"}


def _report(label: str, plan: DistillPlan, alignment: Alignment,
            slice_: Slice) -> str:
    sources = [step.derived_from for step in plan.steps if step.derived_from]
    final = (f"`{plan.package.final_artifact}`" if plan.package.final_artifact
             else "未声明（全量骨架）")
    lines = [
        "# 链路蒸馏报告", "",
        f"- 蒸馏轨迹：`{plan.trace.trace_id}`",
        f"- 经验名：{label}",
        f"- 来源步骤：{'、'.join(f'`{item}`' for item in sources) or '未标注'}",
        f"- 固化策略：`{plan.policy}`"
        + ("（llm 节点必须带可解析的 from，且来源不能是固定命令）"
           if plan.policy == POLICY_SCRIPTS_FIRST else "（按 agent 判断接受 llm 节点）"),
        f"- 最终产物：{final}",
        "- 链路完整性：" + ("已按 " + "、".join(f"`{item}`" for item in plan.chain_traces)
                             + " 校验" if plan.chain_traces else "未提供来源轨迹，未校验"),
        "- 输入绑定：" + ("、".join(f"`{key}` = `{value}`" for key, value in plan.bound)
                          or "无根输入"),
        f"- 草稿：`{plan.directory}`",
        "",
        "| # | 类型 | 命令 / 提示 | 来源 | 输入 | 产出 |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    if plan.boundaries:
        lines.extend([""] + [f"- 输入边界：{item}" for item in plan.boundaries])
    if plan.materialized:
        lines.extend([""] + [f"- 脚本参数已物化：`{key}` → `{path}`（随包搬运，不再作为输入边界）"
                             for key, path in plan.materialized])
    if plan.materialize_notes:
        lines.extend([""] + [f"- {note}" for note in plan.materialize_notes])
    for step in plan.steps:
        command = step.run.replace("|", "\\|")
        lines.append(f"| {step.order} | {step.kind} | `{command}` | {step.derived_from or '-'} | "
                     f"{'、'.join(step.reads) or '-'} | {'、'.join(step.writes) or '-'} |")
    lines.extend(["", render_alignment(alignment), "\n",
                  render_slice(slice_, alignment.slots), "\n",
                  render_emit(plan.package)])
    return "\n".join(lines)


def distill(service: GenomeService, *, label: str, steps: Sequence[Any],
            workspace: Any, final_artifact: str | None = None,
            asset_id: str | None = None, description: str | None = None,
            source_traces: Sequence[str] = (), owner: str = "local",
            version: str | None = None,
            threshold: float = DEFAULT_THRESHOLD,
            references: Sequence[Mapping[str, Any]] | None = None,
            gaps: Sequence[Mapping[str, Any]] | None = None,
            declarations: Mapping[str, Any] | None = None,
            traces: Sequence[Trace] = (),
            params: Mapping[str, Any] | None = None,
            policy: str = POLICY_SCRIPTS_FIRST) -> DistillPlan:
    """Turn a distilled chain into a compiled package the capture stages accept."""
    try:
        policy = normalize_policy(policy)
    except ValueError as exc:
        raise DistillError(str(exc)) from exc
    planned = plan_steps(steps)
    _reject_gaps_naming_commands(gaps, traces)
    _check_llm_promotions(planned, traces, policy)
    final_token: str | None = None
    if final_artifact is not None:
        final_token = _check_final_artifact(final_artifact, planned, params)
    # The chain check reads the plan as the agent wrote it: a `{script}` placeholder is
    # an explicit boundary there, while the frozen path it is rewritten to would look
    # like a dropped upstream step.
    boundaries = _check_chain(traces, planned, params)
    rewritten, remaining, materialized, materialize_notes = _materialize_scripts(
        planned, params, workspace)
    frozen = {key for key, _ in materialized}
    boundaries = tuple(text for key, text in boundaries if key not in frozen)
    if final_token is not None and (key := placeholder_key(final_token)) is not None:
        final_token = dict(materialized).get(key, final_token)
    document = trace_document(label, rewritten, source_traces=source_traces)
    trace = capture_trace(json.dumps(document))
    alignment = align_traces([trace], threshold)
    directory = service.root / "distills" / trace.trace_id
    try:
        slice_ = reverse_slice(alignment, final_token, bindings(params))
        package = build_package(directory / "package", alignment=alignment,
                                slice_=slice_, traces=[trace], label=label,
                                workspace=workspace, owner=owner,
                                version=version or DEFAULT_VERSION,
                                description=description, asset_id=asset_id,
                                references=references, gaps=gaps,
                                declarations=declarations,
                                bindings=bindings(params),
                                resolve_asset=asset_resolver(service))
    except (SliceError, EmitError, CompileError) as exc:
        raise DistillError(f"{exc}（草稿：{directory / 'package'}）") from exc
    bound = _bound_values(package, rewritten, remaining if params is not None else None)
    plan = DistillPlan(trace, document, rewritten, directory, package, slice_.auxiliary,
                       tuple(trace.trace_id for trace in traces), boundaries, bound,
                       materialized, materialize_notes, policy)
    plan.report_path.parent.mkdir(parents=True, exist_ok=True)
    plan.report_path.write_text(_report(label, plan, alignment, slice_), encoding="utf-8")
    return plan
