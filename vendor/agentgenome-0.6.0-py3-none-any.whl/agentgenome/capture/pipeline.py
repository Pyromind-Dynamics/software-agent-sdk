"""Capture pipeline: traces in, published experience out.

The heavy lifting lives in the stage modules; this module only wires them and
decides what to do when a stage degrades (no new parameters, failing replay).
Every degradation is written into the report, never swallowed.

Nothing here executes a graph: replay A is queued on the host and replay B runs
when that run finalizes, so a capture call returns as soon as the package is
frozen.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence
from uuid import uuid4

from builder import CompileError

from ..service import GenomeService
from .align import DEFAULT_THRESHOLD, Alignment, align_traces, render_alignment
from .emit import (DEFAULT_VERSION, EmitError, Package, build_package, render_emit,
                   source_for)
from .replay import queue_replay, render_plan
from .sample import sample_inputs
from .slice import OUTPUT_CONTRACT_HINT, Slice, SliceError, render_slice, reverse_slice
from .trace import Trace

_SEMVER = re.compile(r"(\d+)\.(\d+)\.(\d+)\Z")


class CaptureError(ValueError):
    pass


@dataclass(frozen=True)
class CapturePlan:
    capture_id: str
    asset_id: str
    version: str
    pin: str
    package_dir: Path
    scope: str
    run_id: str | None
    reused: bool
    generalized: bool | None
    notes: tuple[str, ...]
    report_path: Path
    samples: dict[str, Any] | None = None

    def payload(self) -> dict[str, Any]:
        return {
            "capture_id": self.capture_id,
            "asset_id": self.asset_id,
            "version": self.version,
            "pin": self.pin,
            "scope": self.scope,
            "run_id": self.run_id,
            "reused": self.reused,
            "generalized": self.generalized,
            "notes": list(self.notes),
            "report": str(self.report_path),
            "package": str(self.package_dir),
            "samples": (self.samples or {}).get("index"),
        }


def next_version(versions: Sequence[str]) -> str:
    parsed = [tuple(int(part) for part in match.groups())
              for value in versions if (match := _SEMVER.fullmatch(value))]
    if not parsed:
        raise CaptureError("无法自动递增版本，请显式指定 version")
    major, minor, patch = max(parsed)
    return f"{major}.{minor}.{patch + 1}"


def _header(capture_id: str, label: str, package: Package, traces: Sequence[Trace]) -> str:
    ids = "、".join(f"`{trace.trace_id}`" for trace in traces)
    return "\n".join([
        "# 轨迹沉淀报告", "",
        f"- capture：`{capture_id}`",
        f"- 经验名：{label}",
        f"- 资产：`{package.asset_id}` v{package.version}（owner {package.owner}）",
        f"- 轨迹：{ids}",
        f"- 步骤：{'、'.join(f'{trace.trace_id} {len(trace.steps)} 条' for trace in traces)}",
        "",
    ])


def _report(capture_id: str, label: str, package: Package, traces: Sequence[Trace],
            alignment: Alignment, slice_: Slice, plan: str,
            samples: Mapping[str, Any] | None = None) -> str:
    sections = [render_alignment(alignment), render_slice(slice_, alignment.slots),
                render_emit(package)]
    if samples:
        sections.append(render_samples(samples))
    return "".join([_header(capture_id, label, package, traces), "\n",
                    "\n".join(sections), "\n", plan])


def render_samples(samples: Mapping[str, Any]) -> str:
    """The sampled inputs, as the report tells them: what was kept and what was not."""
    lines = ["### 输入采样", ""]
    if samples.get("error"):
        lines.append(f"- 采样失败：{samples['error']}")
    files = samples.get("files") or ()
    if not files:
        lines.append("- 本条链路没有可采样的根输入")
    for entry in files:
        schema = entry.get("schema") or {}
        names = schema.get("columns") or schema.get("fields") or []
        detail = "、".join(f"`{name}`" for name in names)
        size = "大小未知" if entry.get("bytes") is None else f"{entry['bytes']} B"
        lines.append(
            f"- `{entry.get('key')}` ← `{entry.get('path')}`：{entry.get('format')}"
            + (f"，字段 {detail}" if detail else "")
            + f"，{size}"
            + ("，只采样文件头部" if entry.get("truncated") else "")
            + (f"，{entry['note']}" if entry.get("note") else ""))
    lines.extend(["", f"- 采样索引：`{samples.get('index')}`", ""])
    return "\n".join(lines)


def _samples(workspace: Any, bound: Mapping[str, Any], directory: Path) -> dict[str, Any]:
    """Sampling is evidence: a broken input is reported, never raised."""
    try:
        return sample_inputs(source_for(workspace), bound, directory)
    except Exception as exc:
        return {"index": None, "files": [], "error": f"{type(exc).__name__}: {exc}"[:300]}


def _failure_report(capture_id: str, label: str, traces: Sequence[Trace],
                    alignment: Alignment, slice_: Slice | None, package_dir: Path,
                    error: str) -> str:
    """The report a failed build leaves behind: what was planned, and why it stopped."""
    lines = [
        "# 轨迹沉淀报告（构建失败）", "",
        f"- capture：`{capture_id}`",
        f"- 经验名：{label}",
        f"- 轨迹：{'、'.join(f'`{trace.trace_id}`' for trace in traces)}",
        f"- 草稿：`{package_dir}`",
        f"- 错误：{error}",
        f"- 契约：{OUTPUT_CONTRACT_HINT}",
        "",
        render_alignment(alignment),
        "",
    ]
    lines.append("反向切片未生成：最终产物无法回溯。\n" if slice_ is None
                 else render_slice(slice_, alignment.slots) + "\n")
    return "\n".join(lines)


def _probe_plan(package: Package, new_params: Mapping[str, Any] | None,
                bound: Mapping[str, Any]) -> tuple[dict[str, str] | None, str]:
    """Replay B's parameters, or None plus the note explaining why there is none."""
    requested = {key: str(value) for key, value in (new_params or {}).items()}
    if not requested:
        return None, "未提供换参数回放数据，本条经验未经泛化验证"
    if requested == dict(bound):
        return None, "换参数回放与原参数相同，不构成泛化证据"
    return requested, "换参数回放将在回放 A 成功后由服务执行"


def _require_declared_gaps(package: Package) -> None:
    """A chain that drops steps must say so; reuse cannot infer it from the graph."""
    if not package.not_solidifiable or package.gaps:
        return
    dropped = "；".join(f"#{order} {reason}"
                        for order, reason in package.not_solidifiable)
    raise EmitError(
        f"链路里有无法机械固化的步骤，不能静默丢弃：{dropped}。"
        "用 genome_distill 提交规范化链路，并在 gaps 里声明它们（配 references 说明怎么做）；"
        "如果这些步骤不在最终产物的依赖里，用 final_artifact 重新切片。")


def asset_resolver(service: GenomeService):
    """Asset pointers resolve to a published version: a draft is not a reuse entry."""
    def resolve(asset_id: str, version: str | None) -> Mapping[str, Any]:
        if version is not None:
            try:
                return service.get(asset_id, version)
            except ValueError as exc:
                raise EmitError(f"reference 资产不存在：{asset_id}@{version}") from exc
        published = [item for item in service.versions(asset_id) if item["published"]]
        if not published:
            raise EmitError(f"reference 资产不存在或未发布：{asset_id}")
        return service.get(asset_id, published[-1]["version"])
    return resolve


def prepare_capture(service: GenomeService, *, traces: Sequence[Trace], label: str,
                    workspace: Any, scope: str, final_artifact: str | None = None,
                    threshold: float = DEFAULT_THRESHOLD, new_params: Mapping[str, Any] | None = None,
                    owner: str = "local", description: str | None = None,
                    version: str | None = None, capture_id: str | None = None,
                    asset_id: str | None = None,
                    references: Sequence[Mapping[str, Any]] | None = None,
                    gaps: Sequence[Mapping[str, Any]] | None = None,
                    declarations: Mapping[str, Any] | None = None,
                    replay_params: Mapping[str, Any] | None = None) -> CapturePlan:
    traces = list(traces)
    if not traces:
        raise CaptureError("至少需要一条轨迹")
    capture_id = capture_id or uuid4().hex
    directory = service.root / "captures" / capture_id
    alignment = align_traces(traces, threshold)
    package_dir = directory / "package"
    slice_: Slice | None = None

    def build(candidate: str) -> Package:
        assert slice_ is not None
        return build_package(package_dir, alignment=alignment, slice_=slice_, traces=traces,
                             label=label, workspace=workspace, owner=owner,
                             version=candidate, description=description, asset_id=asset_id,
                             references=references, gaps=gaps, declarations=declarations,
                             resolve_asset=asset_resolver(service))

    try:
        slice_ = reverse_slice(alignment, final_artifact)
        package = build(version or DEFAULT_VERSION)
        _require_declared_gaps(package)
    except (SliceError, EmitError, CompileError) as exc:
        report = _failure_report(capture_id, label, traces, alignment, slice_,
                                 package_dir, str(exc))
        service.captures.failed(
            capture_id, asset_id=asset_id or "", label=label, report=report,
            error=str(exc), traces=[trace.trace_id for trace in traces],
            package=package_dir)
        raise CaptureError(
            f"capture {capture_id} 构建失败：{exc}"
            f"（草稿：{package_dir}；报告见 genome_capture_status capture_id={capture_id}）"
        ) from exc
    versions = {item["version"]: item for item in service.versions(package.asset_id)}
    existing = {name: item["pin"] for name, item in versions.items()}
    if existing.get(package.version) == package.pin:
        notes = ("与已有版本字节一致，未产生新版本",)
        previous = service.captures.for_asset(package.asset_id, package.version) or {}
        report = _report(capture_id, label, package, traces, alignment, slice_,
                         render_plan(None, None, notes))
        state = service.captures.create(
            capture_id, asset_id=package.asset_id, version=package.version, pin=package.pin,
            scope=scope, run_id=None, package=package.directory, report=report,
            traces=[trace.trace_id for trace in traces],
            generalized=bool(previous.get("generalized")),
            probe=None, notes=notes, reused=True,
            published=bool(versions[package.version]["published"]),
            samples=previous.get("samples"))
        return CapturePlan(capture_id, package.asset_id, package.version, package.pin,
                           package.directory, scope, None, True, state["generalized"],
                           notes, Path(state["report"]), state.get("samples"))
    if version is None and package.version in existing:
        package = build(next_version(list(existing)))

    bound = dict(replay_params) if replay_params is not None else dict(package.params)
    samples = _samples(workspace, bound, directory / "samples")
    probe, note = _probe_plan(package, new_params, bound)
    notes = (note,)
    try:
        case = queue_replay(service, package, bound, scope=scope,
                            request_id=capture_id, name="same")
    except ValueError as exc:
        raise CaptureError(f"草稿导入失败：{exc}") from exc
    report = _report(capture_id, label, package, traces, alignment, slice_,
                     render_plan(probe, case.run_id), samples)
    state = service.captures.create(
        capture_id, asset_id=package.asset_id, version=package.version, pin=package.pin,
        scope=scope, run_id=case.run_id, package=package.directory, report=report,
        traces=[trace.trace_id for trace in traces],
        generalized=False if probe is None else None, probe=probe, notes=notes,
        samples=samples)
    return CapturePlan(capture_id, package.asset_id, package.version, package.pin,
                       package.directory, scope, case.run_id, False, state["generalized"],
                       notes, Path(state["report"]), samples)
