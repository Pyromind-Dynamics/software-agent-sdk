"""Optional manifest metadata: applicability, contracts, references and gaps.

These fields are additive. A package without them stays valid; a package with
them answers "when does this apply, what does it consume, and what is missing
from the graph" without reading the source trace.
"""
from __future__ import annotations

import re
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Sequence

DETERMINISM = ("script", "agent-assisted", "human-gated")
REFERENCE_PREFIX = "references/"
MAX_REFERENCE_BYTES = 256 * 1024
MATCH_KEYS = ("applies_when", "not_applies_when", "input_contract", "output_contract",
              "determinism")
_CONTRACT_KEYS = {"format", "fields", "required_fields", "optional_fields", "description"}
_LIST_KEYS = {"fields", "required_fields", "optional_fields"}
_ASSET_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z")


class ManifestError(ValueError):
    pass


def _text(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ManifestError(f"{where} must be a non-empty string")
    return value.strip()


def _text_list(value: Any, where: str) -> list[str]:
    if not isinstance(value, list):
        raise ManifestError(f"{where} must be a list of strings")
    return [_text(item, f"{where}[{index}]") for index, item in enumerate(value)]


def _contract(value: Any, where: str) -> None:
    if not isinstance(value, Mapping):
        raise ManifestError(f"{where} must be an object keyed by name")
    for name, raw in value.items():
        key = _text(name, f"{where} key")
        if not isinstance(raw, Mapping):
            raise ManifestError(f"{where}.{key} must be an object")
        for field, item in raw.items():
            if field not in _CONTRACT_KEYS:
                raise ManifestError(f"{where}.{key}.{field} is not supported")
            if field in _LIST_KEYS:
                _text_list(item, f"{where}.{key}.{field}")
            else:
                _text(item, f"{where}.{key}.{field}")


def reference_path(value: Any, where: str) -> str:
    path = _text(value, where)
    pure = PurePosixPath(path)
    if pure.is_absolute() or ".." in pure.parts or not path.startswith(REFERENCE_PREFIX):
        raise ManifestError(f"{where} must be a relative path under {REFERENCE_PREFIX}")
    return path


def reference_target(value: Any, where: str) -> str:
    """A gap points at a reference by its packaged path or by the asset it names."""
    target = _text(value, where)
    if target.startswith(REFERENCE_PREFIX):
        return reference_path(target, where)
    if not _ASSET_ID.fullmatch(target):
        raise ManifestError(f"{where} must be a {REFERENCE_PREFIX} path or an asset id")
    return target


def reference_id(entry: Mapping[str, Any]) -> str:
    """How a gap points at a reference: its packaged path, or the asset it names."""
    path = entry.get("path")
    return str(path) if path else str(entry.get("asset_id") or "")


def _asset_pointer(raw: Mapping[str, Any], item: str) -> str:
    asset_id = _text(raw.get("asset_id"), f"{item}.asset_id")
    if not _ASSET_ID.fullmatch(asset_id):
        raise ManifestError(f"{item}.asset_id must be an ASCII slug: {asset_id}")
    for key in ("version", "when"):
        if key in raw:
            _text(raw[key], f"{item}.{key}")
    if "input_mapping" in raw:
        mapping = raw["input_mapping"]
        if not isinstance(mapping, Mapping):
            raise ManifestError(f"{item}.input_mapping must be an object")
        for key, value in mapping.items():
            _text(key, f"{item}.input_mapping key")
            _text(value, f"{item}.input_mapping.{key}")
    return asset_id


def _references(value: Any, where: str, root: Path | None) -> list[str]:
    if not isinstance(value, list):
        raise ManifestError(f"{where} must be a list")
    declared: list[str] = []
    for index, raw in enumerate(value):
        item = f"{where}[{index}]"
        if not isinstance(raw, Mapping):
            raise ManifestError(f"{item} must be an object")
        if "path" in raw and "asset_id" in raw:
            raise ManifestError(f"{item} cannot be both a packaged file and an asset pointer")
        if "asset_id" in raw:
            asset_id = _asset_pointer(raw, item)
            if asset_id in declared:
                raise ManifestError(f"{item}.asset_id duplicates {asset_id}")
            declared.append(asset_id)
            continue
        path = reference_path(raw.get("path"), f"{item}.path")
        if path in declared:
            raise ManifestError(f"{item}.path duplicates {path}")
        for key in ("title", "when"):
            if key in raw:
                _text(raw[key], f"{item}.{key}")
        if root is not None and not (root / path).is_file():
            raise ManifestError(f"{item}.path does not exist: {path}")
        declared.append(path)
    return declared


def _gaps(value: Any, where: str, declared: Sequence[str]) -> None:
    if not isinstance(value, list):
        raise ManifestError(f"{where} must be a list")
    for index, raw in enumerate(value):
        item = f"{where}[{index}]"
        if not isinstance(raw, Mapping):
            raise ManifestError(f"{item} must be an object")
        _text(raw.get("reason"), f"{item}.reason")
        if "step" in raw:
            step = raw["step"]
            if not isinstance(step, int) or isinstance(step, bool) or step < 1:
                raise ManifestError(f"{item}.step must be a positive integer")
        if "reference" in raw:
            target = reference_target(raw["reference"], f"{item}.reference")
            if target not in declared:
                raise ManifestError(f"{item}.reference is not declared in references: {target}")


def validate(manifest: Mapping[str, Any], root: Path | None = None) -> None:
    for key in ("applies_when", "not_applies_when"):
        if key in manifest:
            _text_list(manifest[key], key)
    for key in ("input_contract", "output_contract"):
        if key in manifest:
            _contract(manifest[key], key)
    if "determinism" in manifest and manifest["determinism"] not in DETERMINISM:
        raise ManifestError(f"determinism must be one of {list(DETERMINISM)}")
    declared = (_references(manifest["references"], "references", root)
                if "references" in manifest else [])
    if "gaps" in manifest:
        _gaps(manifest["gaps"], "gaps", declared)
    if manifest.get("determinism") == "script" and manifest.get("gaps"):
        raise ManifestError("determinism cannot be script while gaps are declared")


def view(manifest: Mapping[str, Any]) -> dict[str, Any]:
    """The compact shape genome_list returns: enough to match without genome_get."""
    result = {key: manifest[key] for key in ("id", "version", "name", "description")}
    for key in ("applies_when", "not_applies_when", "input_contract", "determinism"):
        if key in manifest:
            result[key] = manifest[key]
    references = manifest.get("references") or []
    if references:
        result["has_references"] = True
    assets = []
    for item in references:
        if "asset_id" not in item:
            continue
        asset = {"asset_id": item["asset_id"]}
        for key in ("version", "when", "input_mapping"):
            if key in item:
                asset[key] = item[key]
        assets.append(asset)
    if assets:
        result["reference_assets"] = assets
    if manifest.get("gaps"):
        result["has_gaps"] = True
    return result


def declared(manifest: Mapping[str, Any]) -> dict[str, Any]:
    """The manifest's applicability and contract declarations, as captured."""
    return {key: manifest[key] for key in MATCH_KEYS if key in manifest}


def capture_references(entries: Any) -> list[dict[str, Any]]:
    """Normalize capture/distill input into manifest entries plus source paths."""
    if entries is None:
        return []
    if not isinstance(entries, list):
        raise ManifestError("references must be a list")
    normalized: list[dict[str, Any]] = []
    taken: set[str] = set()
    for index, raw in enumerate(entries):
        item = f"references[{index}]"
        if not isinstance(raw, Mapping):
            raise ManifestError(f"{item} must be an object")
        if raw.get("source") is not None and raw.get("asset_id") is not None:
            raise ManifestError(
                f"{item} cannot be both a file (source) and an asset (asset_id)")
        if raw.get("asset_id") is not None:
            entry = {"asset_id": _asset_pointer(raw, item)}
            for key in ("version", "when"):
                if key in raw:
                    entry[key] = _text(raw[key], f"{item}.{key}")
            if "input_mapping" in raw:
                entry["input_mapping"] = {str(key): str(value)
                                          for key, value in raw["input_mapping"].items()}
            normalized.append(entry)
            continue
        source = _text(raw.get("source"), f"{item}.source")
        name = PurePosixPath(source).name
        if not name:
            raise ManifestError(f"{item}.source must name a file")
        path = f"{REFERENCE_PREFIX}{name}"
        if path in taken:
            raise ManifestError(f"{item}.source collides with another reference at {path}")
        taken.add(path)
        entry: dict[str, Any] = {"source": source, "path": path}
        for key in ("title", "when"):
            if key in raw:
                entry[key] = _text(raw[key], f"{item}.{key}")
        normalized.append(entry)
    return normalized


def capture_gaps(entries: Any, reference_paths: Sequence[str]) -> list[dict[str, Any]]:
    if entries is None:
        return []
    if not isinstance(entries, list):
        raise ManifestError("gaps must be a list")
    normalized: list[dict[str, Any]] = []
    for index, raw in enumerate(entries):
        item = f"gaps[{index}]"
        if not isinstance(raw, Mapping):
            raise ManifestError(f"{item} must be an object")
        entry: dict[str, Any] = {"reason": _text(raw.get("reason"), f"{item}.reason")}
        if "step" in raw:
            step = raw["step"]
            if not isinstance(step, int) or isinstance(step, bool) or step < 1:
                raise ManifestError(f"{item}.step must be a positive integer")
            entry["step"] = step
        if "reference" in raw:
            target = reference_target(raw["reference"], f"{item}.reference")
            if target not in reference_paths:
                raise ManifestError(f"{item}.reference is not declared in references: {target}")
            entry["reference"] = target
        normalized.append(entry)
    return normalized
