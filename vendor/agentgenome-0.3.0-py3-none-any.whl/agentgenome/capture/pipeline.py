"""Capture pipeline: traces in, published experience out.

The heavy lifting lives in the stage modules; this module only wires them and
decides what to do when a stage degrades (no new parameters, failing replay).
Every degradation is written into the report, never swallowed.

Nothing here executes a graph: replay A is queued on the host and replay B runs
when that run finalizes, so a capture call returns as soon as the package is
frozen.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence
from uuid import uuid4

from ..service import GenomeService
from .align import DEFAULT_THRESHOLD, Alignment, align_traces, render_alignment
from .emit import DEFAULT_VERSION, Package, build_package, render_emit
from .replay import queue_replay, render_plan
from .slice import Slice, render_slice, reverse_slice
from .trace import Trace

_SEMVER = re.compile(r"(\d+)\.(\d+)\.(\d+)\Z")


class CaptureError(ValueError):
    pass


@dataclass(frozen=True)
class CapturePlan:
    capture_id: str
    asset_id: str
    version: str
    pin: str
    package_dir: Path
    scope: str
    run_id: str | None
    reused: bool
    generalized: bool | None
    notes: tuple[str, ...]
    report_path: Path

    def payload(self) -> dict[str, Any]:
        return {
            "capture_id": self.capture_id,
            "asset_id": self.asset_id,
            "version": self.version,
            "pin": self.pin,
            "scope": self.scope,
            "run_id": self.run_id,
            "reused": self.reused,
            "generalized": self.generalized,
            "notes": list(self.notes),
            "report": str(self.report_path),
            "package": str(self.package_dir),
        }


def next_version(versions: Sequence[str]) -> str:
    parsed = [tuple(int(part) for part in match.groups())
              for value in versions if (match := _SEMVER.fullmatch(value))]
    if not parsed:
        raise CaptureError("无法自动递增版本，请显式指定 version")
    major, minor, patch = max(parsed)
    return f"{major}.{minor}.{patch + 1}"


def _header(capture_id: str, label: str, package: Package, traces: Sequence[Trace]) -> str:
    ids = "、".join(f"`{trace.trace_id}`" for trace in traces)
    return "\n".join([
        "# 轨迹沉淀报告", "",
        f"- capture：`{capture_id}`",
        f"- 经验名：{label}",
        f"- 资产：`{package.asset_id}` v{package.version}（owner {package.owner}）",
        f"- 轨迹：{ids}",
        f"- 步骤：{'、'.join(f'{trace.trace_id} {len(trace.steps)} 条' for trace in traces)}",
        "",
    ])


def _report(capture_id: str, label: str, package: Package, traces: Sequence[Trace],
            alignment: Alignment, slice_: Slice, plan: str) -> str:
    return "".join([
        _header(capture_id, label, package, traces),
        "\n",
        render_alignment(alignment),
        "\n",
        render_slice(slice_, alignment.slots),
        "\n",
        render_emit(package),
        "\n",
        plan,
    ])


def _probe_plan(package: Package, new_params: Mapping[str, Any] | None
                ) -> tuple[dict[str, str] | None, str]:
    """Replay B's parameters, or None plus the note explaining why there is none."""
    requested = {key: str(value) for key, value in (new_params or {}).items()}
    if not requested:
        return None, "未提供换参数回放数据，本条经验未经泛化验证"
    if requested == dict(package.params):
        return None, "换参数回放与原参数相同，不构成泛化证据"
    return requested, "换参数回放将在回放 A 成功后由服务执行"


def prepare_capture(service: GenomeService, *, traces: Sequence[Trace], label: str,
                    workspace: Any, scope: str, final_artifact: str | None = None,
                    threshold: float = DEFAULT_THRESHOLD, new_params: Mapping[str, Any] | None = None,
                    owner: str = "local", description: str | None = None,
                    version: str | None = None, capture_id: str | None = None,
                    asset_id: str | None = None) -> CapturePlan:
    traces = list(traces)
    if not traces:
        raise CaptureError("至少需要一条轨迹")
    capture_id = capture_id or uuid4().hex
    directory = service.root / "captures" / capture_id
    alignment = align_traces(traces, threshold)
    slice_ = reverse_slice(alignment, final_artifact)
    package_dir = directory / "package"

    def build(candidate: str) -> Package:
        return build_package(package_dir, alignment=alignment, slice_=slice_, traces=traces,
                             label=label, workspace=workspace, owner=owner,
                             version=candidate, description=description, asset_id=asset_id)

    package = build(version or DEFAULT_VERSION)
    versions = {item["version"]: item for item in service.versions(package.asset_id)}
    existing = {name: item["pin"] for name, item in versions.items()}
    if existing.get(package.version) == package.pin:
        notes = ("与已有版本字节一致，未产生新版本",)
        report = _report(capture_id, label, package, traces, alignment, slice_,
                         render_plan(None, None, notes))
        state = service.captures.create(
            capture_id, asset_id=package.asset_id, version=package.version, pin=package.pin,
            scope=scope, run_id=None, package=package.directory, report=report,
            traces=[trace.trace_id for trace in traces],
            generalized=bool((service.captures.for_asset(package.asset_id, package.version)
                              or {}).get("generalized")),
            probe=None, notes=notes, reused=True,
            published=bool(versions[package.version]["published"]))
        return CapturePlan(capture_id, package.asset_id, package.version, package.pin,
                           package.directory, scope, None, True, state["generalized"],
                           notes, Path(state["report"]))
    if version is None and package.version in existing:
        package = build(next_version(list(existing)))

    probe, note = _probe_plan(package, new_params)
    notes = (note,)
    try:
        case = queue_replay(service, package, dict(package.params), scope=scope,
                            request_id=capture_id, name="same")
    except ValueError as exc:
        raise CaptureError(f"草稿导入失败：{exc}") from exc
    report = _report(capture_id, label, package, traces, alignment, slice_,
                     render_plan(probe, case.run_id))
    state = service.captures.create(
        capture_id, asset_id=package.asset_id, version=package.version, pin=package.pin,
        scope=scope, run_id=case.run_id, package=package.directory, report=report,
        traces=[trace.trace_id for trace in traces],
        generalized=False if probe is None else None, probe=probe, notes=notes)
    return CapturePlan(capture_id, package.asset_id, package.version, package.pin,
                       package.directory, scope, case.run_id, False, state["generalized"],
                       notes, Path(state["report"]))
