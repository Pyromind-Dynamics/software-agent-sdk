"""Stage C-1: keep only the skeleton steps the final artifact depends on.

The slice is the reverse closure of the write/read edges: start at the step that
produces the declared final artifact, then walk back through every input that some
earlier step produced. Skeleton steps outside that closure are auxiliary: they ran,
but the artifact does not depend on them.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from .align import ROLE_SKELETON, Alignment, Slot


class SliceError(ValueError):
    pass


@dataclass(frozen=True)
class Slice:
    nodes: tuple[int, ...]
    auxiliary: tuple[int, ...]
    final_artifact: str | None
    producers: tuple[tuple[str, int], ...]

    @property
    def full(self) -> bool:
        return self.final_artifact is None


def producer_map(slots: Sequence[Slot]) -> dict[str, int]:
    """Last skeleton writer wins: a later step overwrites the earlier product."""
    result: dict[str, int] = {}
    for order, slot in enumerate(slots):
        if slot.role != ROLE_SKELETON:
            continue
        for path in slot.write_paths:
            result[path] = order
    return result


def reverse_slice(alignment: Alignment, final_artifact: str | None = None) -> Slice:
    slots = alignment.slots
    producers = producer_map(slots)
    skeleton = tuple(order for order, slot in enumerate(slots) if slot.role == ROLE_SKELETON)
    if not skeleton:
        raise SliceError("没有骨架步骤，无法生成图")
    if final_artifact is None:
        return Slice(skeleton, (), None, tuple(sorted(producers.items())))
    root = producers.get(final_artifact)
    if root is None:
        raise SliceError(f"最终产物 {final_artifact!r} 不在任何骨架步骤的产物里")
    keep = {root}
    stack = [root]
    while stack:
        order = stack.pop()
        for path in slots[order].read_paths:
            source = producers.get(path)
            if source is not None and source < order and source not in keep:
                keep.add(source)
                stack.append(source)
    nodes = tuple(sorted(keep))
    return Slice(
        nodes=nodes,
        auxiliary=tuple(order for order in skeleton if order not in keep),
        final_artifact=final_artifact,
        producers=tuple(sorted(producers.items())),
    )


def slice_payload(slice_: Slice, slots: Sequence[Slot]) -> dict[str, object]:
    return {
        "final_artifact": slice_.final_artifact,
        "full": slice_.full,
        "nodes": [
            {"order": order, "shape": slots[order].command_shape,
             "writes": list(slots[order].write_paths)}
            for order in slice_.nodes
        ],
        "auxiliary": [
            {"order": order, "shape": slots[order].command_shape,
             "writes": list(slots[order].write_paths)}
            for order in slice_.auxiliary
        ],
    }


def render_slice(slice_: Slice, slots: Sequence[Slot]) -> str:
    lines = ["### 反向切片", ""]
    if slice_.full:
        lines.append("- 未声明最终产物，使用全量骨架")
    else:
        lines.append(f"- 最终产物：`{slice_.final_artifact}`")
    lines.append(f"- 入图 {len(slice_.nodes)} 步 / 辅助 {len(slice_.auxiliary)} 步")
    if slice_.auxiliary:
        lines.extend(["", "| # | 辅助步骤 | 产出 |", "| --- | --- | --- |"])
        for order in slice_.auxiliary:
            slot = slots[order]
            shape = slot.command_shape.replace("|", "\\|") or "-"
            lines.append(f"| {order} | `{shape}` | {','.join(slot.write_paths) or '-'} |")
    return "\n".join(lines) + "\n"
