"""Stage 0: an explicit plan in, a capture-ready trace out.

The mechanical stages only solidify commands whose inputs and outputs are on the
command line, so a session full of probes, inline code and script-internal writes
cannot be captured as it stands. Distilling is the agent's job: it reads the
session, decides which steps are the business chain, materialises the scripts on
disk and declares every path on the command line. This module holds the result to
the same contract the capture stages enforce, and says what to fix instead of
half-building a graph.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from builder import CompileError

from ..service import GenomeService
from .align import DEFAULT_THRESHOLD, Alignment, align_traces, render_alignment
from .emit import DEFAULT_VERSION, EmitError, Package, build_package, render_emit
from .slice import OUTPUT_CONTRACT_HINT, Slice, SliceError, render_slice, reverse_slice
from .trace import INLINE_MARK, TRACE_VERSION, Command, Trace, capture_trace, parse_command
from .trace import probe_command

MAX_STEPS = 200
AUXILIARY_REASON = ("产出没有被链路里的后续步骤消费，不在最终产物的依赖闭包里；"
                    "要固化它，请单独用 final_artifact 指向它的产出再沉淀一条经验")


class DistillError(ValueError):
    pass


@dataclass(frozen=True)
class DistilledStep:
    order: int
    run: str
    derived_from: str | None
    reads: tuple[str, ...]
    writes: tuple[str, ...]

    def payload(self) -> dict[str, Any]:
        return {
            "step": self.order,
            "run": self.run,
            "from": self.derived_from,
            "reads": list(self.reads),
            "writes": list(self.writes),
        }


def _run_text(raw: Mapping[str, Any], order: int) -> str:
    value = raw.get("run")
    if not isinstance(value, str) or not value.strip():
        raise DistillError(f"第 {order} 步缺少 run：要执行的完整 shell 命令")
    return value.strip()


def _check_command(run: str, command: Command, order: int) -> None:
    if INLINE_MARK in command.shape:
        raise DistillError(
            f"第 {order} 步是内联代码，无法机械固化：`{run}`。"
            "请把代码落盘成脚本文件，再用命令行调用它；heredoc 与 -c 都不算落盘")
    if probe_command(command):
        raise DistillError(
            f"第 {order} 步是只读探测命令，不会进图：`{run}`。请删掉它，只留业务链路")
    if not command.read_paths and not command.write_paths:
        raise DistillError(
            f"第 {order} 步既没有输入也没有产出（命令里没有可识别的路径）：`{run}`。"
            "请把输入和产出写成命令行上的路径")


def plan_steps(steps: Sequence[Any]) -> tuple[DistilledStep, ...]:
    """Validate the agent's chain against the capture contract, step by step."""
    if isinstance(steps, (str, bytes)) or not isinstance(steps, Sequence) or not steps:
        raise DistillError("distill 需要 steps：[{run, from?}]，按链路顺序排列")
    if len(steps) > MAX_STEPS:
        raise DistillError(f"步骤过多（{len(steps)}），最多 {MAX_STEPS} 步")
    planned: list[DistilledStep] = []
    for order, raw in enumerate(steps, start=1):
        if not isinstance(raw, Mapping):
            raise DistillError(f"第 {order} 步必须是对象：{{run, from?}}")
        run = _run_text(raw, order)
        derived = raw.get("from")
        if derived is not None and (not isinstance(derived, str) or not derived.strip()):
            raise DistillError(
                f"第 {order} 步的 from 必须是非空字符串（来源轨迹，如 `<trace_id>:<seq>`）")
        command = parse_command(run)
        _check_command(run, command, order)
        planned.append(DistilledStep(order, run, derived.strip() if derived else None,
                                     command.read_paths, command.write_paths))
    return tuple(planned)


def _trace_id(label: str, steps: Sequence[DistilledStep],
              source_traces: Sequence[str]) -> str:
    """The same plan always distils to the same trace, so a retry is a reuse."""
    material = json.dumps([label, [step.run for step in steps], list(source_traces)],
                          ensure_ascii=False)
    return f"distilled-{hashlib.sha256(material.encode('utf-8')).hexdigest()[:12]}"


def trace_document(label: str, steps: Sequence[DistilledStep], *,
                   source_traces: Sequence[str] = ()) -> dict[str, Any]:
    """A trace the capture stages accept, carrying where each step came from."""
    return {
        "trace_version": TRACE_VERSION,
        "trace_id": _trace_id(label, steps, source_traces),
        "session_id": None,
        "session_name": label,
        "step_count": len(steps),
        "dropped_steps": 0,
        "source_traces": list(source_traces),
        "steps": [
            {
                "kind": "tool",
                "entry_id": step.derived_from or f"distilled-{step.order}",
                "timestamp": None,
                "tool": "terminal",
                "call_id": f"distilled-{step.order}",
                "args": {"command": step.run},
                "result": {"is_error": False, "text": "distilled"},
            }
            for step in steps
        ],
    }


def _check_final_artifact(final_artifact: str, steps: Sequence[DistilledStep]) -> None:
    if any(final_artifact in step.writes for step in steps):
        return
    produced = [path for step in steps for path in step.writes]
    detail = ("计划里的产出：" + "、".join(f"`{path}`" for path in produced[:8])
              if produced else "计划里没有任何产出")
    raise DistillError(
        f"final_artifact `{final_artifact}` 没有被任何步骤声明为产出；{detail}。"
        f"{OUTPUT_CONTRACT_HINT}")


@dataclass(frozen=True)
class DistillPlan:
    trace: Trace
    document: dict[str, Any]
    steps: tuple[DistilledStep, ...]
    directory: Path
    package: Package
    auxiliary: tuple[int, ...]

    @property
    def report_path(self) -> Path:
        return self.directory / "report.md"

    def payload(self) -> dict[str, Any]:
        return {
            "trace_id": self.trace.trace_id,
            "trace": self.document,
            "report": str(self.report_path),
            "package": str(self.package.directory),
            "steps": [step.payload() for step in self.steps],
            "params": [{"key": key, "source": path} for key, path in self.package.params],
            "scripts": [{"source": source, "package": target}
                        for source, target in self.package.scripts],
            "nodes": [{"step": node.order + 1, "id": node.id, "command": node.command}
                      for node in self.package.nodes],
            "not_solidifiable": [{"step": order + 1, "reason": reason}
                                 for order, reason in self.package.not_solidifiable],
            "auxiliary": [{"step": order + 1, "reason": AUXILIARY_REASON}
                          for order in self.auxiliary],
            "final_artifact": self.package.final_artifact,
        }

    def summary(self) -> dict[str, Any]:
        """The payload without the trace document: a caller already has the trace."""
        return {key: value for key, value in self.payload().items() if key != "trace"}


def _report(label: str, plan: DistillPlan, alignment: Alignment,
            slice_: Slice) -> str:
    sources = [step.derived_from for step in plan.steps if step.derived_from]
    final = (f"`{plan.package.final_artifact}`" if plan.package.final_artifact
             else "未声明（全量骨架）")
    lines = [
        "# 链路蒸馏报告", "",
        f"- 蒸馏轨迹：`{plan.trace.trace_id}`",
        f"- 经验名：{label}",
        f"- 来源步骤：{'、'.join(f'`{item}`' for item in sources) or '未标注'}",
        f"- 最终产物：{final}",
        f"- 草稿：`{plan.directory}`",
        "",
        "| # | 命令 | 来源 | 输入 | 产出 |",
        "| --- | --- | --- | --- | --- |",
    ]
    for step in plan.steps:
        command = step.run.replace("|", "\\|")
        lines.append(f"| {step.order} | `{command}` | {step.derived_from or '-'} | "
                     f"{'、'.join(step.reads) or '-'} | {'、'.join(step.writes) or '-'} |")
    lines.extend(["", render_alignment(alignment), "\n",
                  render_slice(slice_, alignment.slots), "\n",
                  render_emit(plan.package)])
    return "\n".join(lines)


def distill(service: GenomeService, *, label: str, steps: Sequence[Any],
            workspace: Any, final_artifact: str | None = None,
            asset_id: str | None = None, description: str | None = None,
            source_traces: Sequence[str] = (), owner: str = "local",
            version: str | None = None,
            threshold: float = DEFAULT_THRESHOLD) -> DistillPlan:
    """Turn a distilled chain into a compiled package the capture stages accept."""
    planned = plan_steps(steps)
    if final_artifact is not None:
        _check_final_artifact(final_artifact, planned)
    document = trace_document(label, planned, source_traces=source_traces)
    trace = capture_trace(json.dumps(document))
    alignment = align_traces([trace], threshold)
    directory = service.root / "distills" / trace.trace_id
    try:
        slice_ = reverse_slice(alignment, final_artifact)
        package = build_package(directory / "package", alignment=alignment,
                                slice_=slice_, traces=[trace], label=label,
                                workspace=workspace, owner=owner,
                                version=version or DEFAULT_VERSION,
                                description=description, asset_id=asset_id)
    except (SliceError, EmitError, CompileError) as exc:
        raise DistillError(f"{exc}（草稿：{directory / 'package'}）") from exc
    plan = DistillPlan(trace, document, planned, directory, package, slice_.auxiliary)
    plan.report_path.parent.mkdir(parents=True, exist_ok=True)
    plan.report_path.write_text(_report(label, plan, alignment, slice_), encoding="utf-8")
    return plan
